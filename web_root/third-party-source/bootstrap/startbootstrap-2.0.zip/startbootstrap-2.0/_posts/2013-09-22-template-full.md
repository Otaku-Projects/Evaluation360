---
layout: post
title: "Full"
slug: full
source: /template-overviews/full
categories: template landing-pages portfolios unstyled
description: Full page image background template.
---

<img src="/assets/img/templates/full.jpg" class="img-responsive" alt="Bootstrap Full Page Image Background">