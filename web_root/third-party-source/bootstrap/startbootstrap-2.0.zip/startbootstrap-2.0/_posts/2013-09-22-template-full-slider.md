---
layout: post
title: "Full Slider"
slug: full-slider
source: /template-overviews/full-slider
categories: template landing-pages one-page portfolios unstyled
description: A full page image slider template.
---

<img src="/assets/img/templates/full-slider.jpg" class="img-responsive" alt="Full Page Bootstrap Image Carousel Slider">