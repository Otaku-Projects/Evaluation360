---
layout: post
title: "Pixel Admin"
slug: pixel-admin
source: http://wrapbootstrap.com/preview/WB07403R9?ref=StartBootstrap
purchase-link: "https://wrapbootstrap.com/theme/pixeladmin-premium-admin-theme-WB07403R9?ref=StartBootstrap"
categories: premium
description: Premium Admin Theme
---

<img src="/assets/img/premium/pixel-admin.jpg" class="img-responsive" alt="Pixel Admin - Premium Admin Theme">