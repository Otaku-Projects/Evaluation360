---
layout: post
title: "Bare"
slug: bare
source: /template-overviews/bare
categories: template landing-pages unstyled navigation-menus popular
description: A Bootstrap HTML starter template.
---

<img src="/assets/img/templates/bare.jpg" class="img-responsive" alt="Bare Bootstrap HTML Starter Template">