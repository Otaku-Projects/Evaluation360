---
layout: post
title: "Blog Post"
slug: blog-post
source: /template-overviews/blog-post
categories: template blogs unstyled
description: A blog post starter template.
---

<img src="/assets/img/templates/blog-post.jpg" class="img-responsive" alt="Free Bootstrap Blog Post Template">