---
layout: post
title: "Grayscale"
slug: grayscale
source: /template-overviews/grayscale
categories: template landing-pages one-page portfolios featured popular
description: A multipurpose one page theme.
---

<img src="/assets/img/templates/grayscale.jpg" class="img-responsive" alt="">