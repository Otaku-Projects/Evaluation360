---
layout: post
title: "The Big Picture"
slug: the-big-picture
source: /template-overviews/the-big-picture
categories: template landing-pages portfolios unstyled
description: A starter portfolio template.
---

<img src="/assets/img/templates/the-big-picture.jpg" class="img-responsive" alt="Free Bootstrap Portfolio Template">