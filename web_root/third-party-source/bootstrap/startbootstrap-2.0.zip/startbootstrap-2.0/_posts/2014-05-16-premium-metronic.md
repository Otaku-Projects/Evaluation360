---
layout: post
title: "Metronic"
slug: metronic
source: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=IronSummitMedia
purchase-link: "http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=IronSummitMedia"
categories: premium
description: Responsive Admin Dashboard Template
---

<img src="/assets/img/premium/metronic.jpg" class="img-responsive" alt="Metronic - Responsive Admin Dashboard Template ">