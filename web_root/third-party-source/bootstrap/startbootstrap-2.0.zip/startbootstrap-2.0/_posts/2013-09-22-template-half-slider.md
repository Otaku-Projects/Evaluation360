---
layout: post
title: "Half Slider"
slug: half-slider
source: /template-overviews/half-slider
categories: template landing-pages one-page portfolios unstyled
description: A half page image slider template.
---

<img src="/assets/img/templates/half-slider.jpg" class="img-responsive" alt="Half Page Bootstrap Image Carousel Slider">