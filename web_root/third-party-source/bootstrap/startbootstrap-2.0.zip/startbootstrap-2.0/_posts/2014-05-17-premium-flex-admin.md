---
layout: post
title: "Flex Admin"
slug: flex-admin
source: http://wrapbootstrap.com/preview/WB032SCB1
purchase-link: "https://wrapbootstrap.com/theme/flex-admin-responsive-admin-template-WB032SCB1"
categories: premium
description: Responsive Admin Template
---

<img src="/assets/img/premium/flex-admin.jpg" class="img-responsive" alt="Flex Admin - Bootstrap Admin Theme">