---
layout: post
title: "Shop Homepage"
slug: shop-homepage
source: /template-overviews/shop-homepage
categories: template ecommerce unstyled
description: An online store homepage template.
---

<img src="/assets/img/templates/shop-homepage.jpg" class="img-responsive" alt="Free Bootstrap Ecommerce Template">