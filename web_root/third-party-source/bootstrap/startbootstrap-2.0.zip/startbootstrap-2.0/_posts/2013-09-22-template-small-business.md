---
layout: post
title: "Small Business"
slug: small-business
source: /template-overviews/small-business
categories: template landing-pages unstyled
description: A simple business Bootstrap template.
---

<img src="/assets/img/templates/small-business.jpg" class="img-responsive" alt="Free Small Business Template for Bootstrap 3">