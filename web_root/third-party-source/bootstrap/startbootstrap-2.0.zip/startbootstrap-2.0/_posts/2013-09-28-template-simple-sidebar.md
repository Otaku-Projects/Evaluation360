---
layout: post
title: "Simple Sidebar"
slug: simple-sidebar
source: /template-overviews/simple-sidebar
categories: template unstyled navigation-menus popular
description: A Bootstrap sidebar template.
---

<img src="/assets/img/templates/simple-sidebar.jpg" class="img-responsive" alt="Bootstrap Sidebar Navigation Template">