---
layout: post
title: "Vitality"
slug: vitality
source: http://wrapbootstrap.com/preview/WB02K3KK3
purchase-link: "https://wrapbootstrap.com/theme/vitality-multipurpose-one-page-theme-WB02K3KK3"
categories: premium
description: Multipurpose One Page Theme
---

<img src="/assets/img/premium/vitality.jpg" class="img-responsive" alt="Vitality - One Page Bootstrap Theme">