---
layout: post
title: "Business Frontpage"
slug: business-frontpage
source: /template-overviews/business-frontpage
categories: template landing-pages unstyled
description: A business home page template.
---

<img src="/assets/img/templates/business-frontpage.jpg" class="img-responsive" alt="Free Bootstrap Business Website Template">