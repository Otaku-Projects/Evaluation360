---
layout: post
title: "Portfolio Item"
slug: portfolio-item
source: /template-overviews/portfolio-item
categories: template portfolios unstyled
description: A portfolio item page template.
---

<img src="/assets/img/templates/portfolio-item.jpg" class="img-responsive" alt="Free Bootstrap 3 Portfolio Template">