---
layout: post
title: "Flatify"
slug: flatify
source: http://wrapbootstrap.com/preview/WB0977873?ref=StartBootstrap
purchase-link: "https://wrapbootstrap.com/theme/flatify-responsive-admin-web-app-WB0977873?ref=StartBootstrap"
categories: premium
description: Responsive Admin Web App
---

<img src="/assets/img/premium/flatify.jpg" class="img-responsive" alt="Flatify - Responsive Admin Web App">