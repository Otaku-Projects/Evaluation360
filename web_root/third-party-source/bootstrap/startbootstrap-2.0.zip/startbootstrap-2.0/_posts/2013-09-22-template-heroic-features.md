---
layout: post
title: "Heroic Features"
slug: heroic-features
source: /template-overviews/heroic-features
categories: template landing-pages ecommerce unstyled
description: A basic Bootstrap home page template.
---

<img src="/assets/img/templates/heroic-features.jpg" class="img-responsive" alt="Basic Bootstrap Home Page Template">