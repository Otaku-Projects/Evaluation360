---
layout: post
title: "Ace Admin"
slug: ace-admin
source: http://wrapbootstrap.com/preview/WB0B30DGR?ref=StartBootstrap
purchase-link: "https://wrapbootstrap.com/theme/ace-responsive-admin-template-WB0B30DGR?ref=StartBootstrap"
categories: premium
description: Responsive Admin Template
---

<img src="/assets/img/premium/ace-admin.jpg" class="img-responsive" alt="Ace Admin - Responsive Admin Template">