---
layout: post
title: "Charlotte Seaberry"
slug: grayscale
source: http://www.charlotteseaberry.com/
categories: showcase
description: Author, Editor, Reader, & Writer
template: "Grayscale"
---

<img src="/assets/img/showcase/charlotte-seaberry.jpg" class="img-responsive" alt="Charlotte Seaberry Author Website">