---
layout: post
title: "SB Admin 2"
slug: sb-admin-2
source: /template-overviews/sb-admin-2
categories: template admin full-websites unstyled featured popular
description: A free Bootstrap admin theme.
---

<img src="/assets/img/templates/sb-admin-2.jpg" class="img-responsive" alt="Free Bootstrap Admin Theme - SB Admin 2">