---
layout: post
title: "Full Width Pics"
slug: full-width-pics
source: /template-overviews/full-width-pics
categories: template landing-pages one-page unstyled
description: Full width picture backgrounds.
---

<img src="/assets/img/templates/full-width-pics.jpg" class="img-responsive" alt="Bootstrap Full Width Picture Page Backgrounds">