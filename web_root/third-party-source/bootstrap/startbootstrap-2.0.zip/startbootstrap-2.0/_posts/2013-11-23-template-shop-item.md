---
layout: post
title: "Shop Item"
slug: shop-item
source: /template-overviews/shop-item
categories: template ecommerce unstyled
description: An online store item template.
---

<img src="/assets/img/templates/shop-item.jpg" class="img-responsive" alt="Free Bootstrap Online Store Template">