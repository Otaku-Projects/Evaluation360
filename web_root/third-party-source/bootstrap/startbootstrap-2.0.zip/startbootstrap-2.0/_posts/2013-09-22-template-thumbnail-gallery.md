---
layout: post
title: "Thumbnail Gallery"
slug: thumbnail-gallery
source: /template-overviews/thumbnail-gallery
categories: template unstyled
description: A simple image gallery template.
---

<img src="/assets/img/templates/thumbnail-gallery.jpg" class="img-responsive" alt="Bootstrap Image Gallery Template">