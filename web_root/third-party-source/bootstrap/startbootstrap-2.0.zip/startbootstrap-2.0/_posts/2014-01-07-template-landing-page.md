---
layout: post
title: "Landing Page"
slug: landing-page
source: /template-overviews/landing-page
categories: template landing-pages one-page portfolios featured popular
description: A clean, functional landing page theme.
---

<img src="/assets/img/templates/landing-page.jpg" class="img-responsive" alt="Free Bootstrap Landing Page Theme">