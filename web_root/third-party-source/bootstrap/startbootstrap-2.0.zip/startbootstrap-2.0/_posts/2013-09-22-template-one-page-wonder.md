---
layout: post
title: "One Page Wonder"
slug: one-page-wonder
source: /template-overviews/one-page-wonder
categories: template landing-pages one-page portfolios unstyled popular
description: A simple one page website template.
---

<img src="/assets/img/templates/one-page-wonder.jpg" class="img-responsive" alt="Free Bootstrap One Page Website Template">