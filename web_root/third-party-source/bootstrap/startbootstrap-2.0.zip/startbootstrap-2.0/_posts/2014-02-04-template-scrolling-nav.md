---
layout: post
title: "Scrolling Nav"
slug: scrolling-nav
source: /template-overviews/scrolling-nav
categories: template unstyled navigation-menus
description: A scrolling navigation template.
---

<img src="/assets/img/templates/scrolling-nav.jpg" class="img-responsive" alt="Bootstrap Smooth Scrolling Navigation jQuery">