---
layout: post
title: "Spectrum"
slug: spectrum
source: http://wrapbootstrap.com/preview/WB0317BRF
purchase-link: "https://wrapbootstrap.com/theme/spectrum-flexible-multipurpose-theme-WB0317BRF"
categories: premium
description: Flexible Multipurpose Theme
---

<img src="/assets/img/premium/spectrum.jpg" class="img-responsive" alt="Spectrum - One Page Bootstrap Theme">