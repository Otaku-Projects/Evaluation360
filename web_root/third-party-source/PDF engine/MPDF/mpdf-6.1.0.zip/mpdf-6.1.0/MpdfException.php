<?php

class MpdfException extends Exception
{

}
